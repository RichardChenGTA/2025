/**
 * ica_extractor.js
 * Usage:
 *   node ica_extractor.js ica-output.txt
 */
const fs = require('fs');
const path = require('path');

if (process.argv.length < 3) {
  console.error('Usage: node ica_extractor.js <ica-output.txt> [targetRoot]');
  process.exit(1);
}

const inputFile = process.argv[2];
const targetRoot = process.argv[3] ? path.resolve(process.argv[3]) : process.cwd();
const raw = fs.readFileSync(inputFile, 'utf8');

const lines = raw.replace(/\r\n/g, '\n').split('\n');
const headerRegex = /^\s*([A-Za-z0-9_\-\/]+\/[A-Za-z0-9_\-\.\/]+\.(?:ts|tsx|js|json))\s*:?\s*$/;
const shortHeaderRegex = /^\s*([A-Za-z0-9_\-\.]+\.(?:ts|tsx|js|json))\s*:?\s*$/;

let currentFile = null;
let buffers = {};
let inFence = false;
let fenceBuffer = [];
let narrativeStopPatterns = [
  /^This code follows/i,
  /^This file follows/i,
  /^Richard Created/i,
  /^Here is the complete/i
];

// 定义文件路径映射
const filePathMapping = {
  'LaptopsPage.ts': 'page_objects/LaptopsPage.ts',
  'ProductPage.ts': 'page_objects/ProductPage.ts',
  'CartPage.ts': 'page_objects/CartPage.ts',
  'OrderPage.ts': 'page_objects/OrderPage.ts',
  'demoblaze.test.ts': 'tests/demoblaze.test.ts',
  'orderData.json': 'test_data/orderData.json'
};

function isNarrativeLine(line) {
  return narrativeStopPatterns.some(p => p.test(line));
}

// 跳过文件结构说明部分
let skipFileStructure = true;
let fileStructureSection = false;

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  
  // 检测文件结构部分开始
  if (line.includes('File Structure:')) {
    fileStructureSection = true;
    continue;
  }
  
  // 跳过文件结构说明部分的所有行
  if (fileStructureSection) {
    // 文件结构部分结束的条件：遇到代码块或文件头
    if (line.trim().startsWith('```') || line.match(headerRegex) || line.match(shortHeaderRegex)) {
      fileStructureSection = false;
    } else {
      continue;
    }
  }
  
  // 跳过初始的文件结构描述
  if (skipFileStructure) {
    if (line.match(headerRegex) || line.match(shortHeaderRegex)) {
      skipFileStructure = false;
    } else {
      continue;
    }
  }
  
  if (/^-{3,}$/.test(line) || /^\*{3,}$/.test(line)) continue;
  
  // 处理代码块 - 这是关键修复部分
  if (line.trim().startsWith('```')) {
    if (!inFence) {
      // 代码块开始
      inFence = true;
      fenceBuffer = [];
      continue;
    } else {
      // 代码块结束
      inFence = false;
      if (currentFile && fenceBuffer.length > 0) {
        // 将整个代码块内容保存到对应文件
        buffers[currentFile] = [...fenceBuffer];
      }
      fenceBuffer = [];
      continue;
    }
  }
  
  // 如果在代码块中，收集所有行
  if (inFence) {
    fenceBuffer.push(line);
    continue;
  }
  
  // 匹配文件头
  const m = line.match(headerRegex) || line.match(shortHeaderRegex);
  if (m) {
    let fileName = m[1].trim().replace(/\\/g, '/');
    
    // 使用映射表来确定正确的文件路径
    if (filePathMapping[fileName]) {
      currentFile = filePathMapping[fileName];
    } else if (!fileName.includes('/')) {
      // 对于不在映射表中的文件，根据扩展名推断路径
      if (fileName.endsWith('.test.ts') || fileName.endsWith('.spec.ts')) {
        currentFile = 'tests/' + fileName;
      } else if (fileName.endsWith('.json')) {
        currentFile = 'test_data/' + fileName;
      } else if (fileName.endsWith('.ts') || fileName.endsWith('.tsx') || fileName.endsWith('.js')) {
        currentFile = 'page_objects/' + fileName;
      } else {
        currentFile = fileName;
      }
    } else {
      currentFile = fileName;
    }
    
    buffers[currentFile] = buffers[currentFile] || [];
    continue;
  }
  
  if (isNarrativeLine(line)) {
    currentFile = null;
    continue;
  }
  
  // 跳过文件结构相关的行
  if (line.includes('File Structure') || line.trim().startsWith('|') || line.includes('──')) {
    currentFile = null;
    continue;
  }
  
  // 不在代码块中且当前文件有效时，处理非代码块内容
  if (currentFile && !inFence) {
    // 跳过空行和无关的描述文本
    if (line.trim() === '' || 
        line.includes('page_objects/') || 
        line.includes('tests/') || 
        line.includes('test_data/') ||
        line.trim() === '|') {
      continue;
    }
    // 对于非代码块内容，也收集到缓冲区
    if (!buffers[currentFile]) {
      buffers[currentFile] = [];
    }
    buffers[currentFile].push(line);
  }
}

// 写入文件
let fileCount = 0;
for (const relPath of Object.keys(buffers)) {
  let contentLines = buffers[relPath];
  
  // 清理内容：移除前后的空行
  while (contentLines.length && contentLines[0].trim() === '') contentLines.shift();
  while (contentLines.length && contentLines[contentLines.length-1].trim() === '') contentLines.pop();
  
  if (!contentLines.length) continue;
  
  const content = contentLines.join('\n').replace(/\t/g, '  ').trim() + '\n';
  const targetPath = path.join(targetRoot, relPath);
  
  // 确保目录存在
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  fs.writeFileSync(targetPath, content, 'utf8');
  console.log('✓ WROTE:', targetPath);
  fileCount++;
}

console.log(`\nExtraction completed! ${fileCount} files created successfully.`);

// 调试：显示提取的文件内容
console.log('\n=== DEBUG: Extracted test file content ===');
if (buffers['tests/demoblaze.test.ts']) {
  console.log(buffers['tests/demoblaze.test.ts'].join('\n'));
}