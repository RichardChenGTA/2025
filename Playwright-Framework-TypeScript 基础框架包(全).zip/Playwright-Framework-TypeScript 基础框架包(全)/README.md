# Playwright-Framework-TypeScript

# 快捷命令 

npm install

npm install reflect-metadata@latest --save

npx playwright test


# ICA assistant 提示词

Please generate a complete, runnable Playwright E2E test script for the website https://www.demoblaze.com, strictly following our framework conventions:															
Use only the following selectors and actions (from automated element collection):															
goto: https://www.demoblaze.com															
click: text="Laptops"															
click: text="Sony vaio i5"															
click: text="Add to cart"															
click: #cartur															
click: text="Place Order"															
fill: #name with "Test User"															
fill: #country with "Testland"															
fill: #city with "Test City"															
fill: #card with "1234 5678 9012 3456"															
fill: #month with "12"															
fill: #year with "2025"															
click: text="Purchase"															
read: .sweet-alert															
Place page object classes in the page_objects folder, with clear and consistent naming.															
Place test data in the test_data folder as a JSON file (e.g., orderData.json).															
The main test script should be in the tests folder.															
All assertions should be in the test file, not in page objects.															
Output all file names and code for direct copy and run.															
Use Playwright best practices: explicit waits, error handling, and clear assertions.															
Test data example: { "name": "Test User", "country": "Testland", "city": "Test City", "card": "1234 5678 9012 3456", "month": "12", "year": "2025" }		


# 自动化脚本分发

# Step 2: 运行解析器
node ica_extractor.js ica-output.txt

# Step 3: 运行测试
npx playwright test